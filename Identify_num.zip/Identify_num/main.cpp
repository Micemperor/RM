#include <iostream>
#include <cmath>
#include <string>
#include <vector>
#include <opencv2/opencv.hpp>
#include "Identify_num.h"
using namespace std;
using namespace cv;

int main()
{

    //VideoCapture video("/home/micemperor/桌面/Identify_num/test/test2.mp4");
    //if(!video.isOpened())
    //{
    //    cerr<<"无法读取视频!"<<endl;
    //    return -1;
    //}

    //while(1)
    //{
        Mat image = imread("/home/micemperor/桌面/Identify_num/test/test8.png");
        //Mat image;
        //video >> image;
        if(image.empty())
        {
            cerr<<"无法读取图片!"<<endl;
            //break;
        }

        Identify_num Ident(image);
        Mat brightImage = Ident.p_brightImage();
        //for(int color = 1; color <= 3; color++)
        //{
            //Mat ColorImage = Ident.p_colorImage(2);
            //Mat maskLight = Ident.FindLight(brightImage, ColorImage);
            vector<Mat> ROI = Ident.MatchLight(brightImage);
        
            for (size_t i = 0; i < ROI.size(); i++)
            {
                imshow(format("ROI %d",i+1), ROI[i]);

                Mat grayROI = Ident.p_ROI(ROI[i]);
                imshow(format("grayROI %d",i+1), grayROI);   
                int num = Ident.matchNum_Template(grayROI);
                Mat result = imread(format("/home/micemperor/桌面/Identify_num/num/%d.png", num));
                //imshow(format("num %d",i+1),result);
            }
        //}
        

        imshow("image", image);
        waitKey(0);
        //waitKey(1000 / video.get(CAP_PROP_FPS));
    //}
    return 0;
}