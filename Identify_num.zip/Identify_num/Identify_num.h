#include <iostream>
#include <cmath>
#include <string>
#include <vector>
#include <opencv2/opencv.hpp>
using namespace std;
using namespace cv;

#ifndef IDENTIFY_NUM_H
#define IDENTIFY_NUM_H

class Identify_num
{
public:
    Identify_num(Mat& img);

    ~Identify_num();

    Mat image;
    int n = 0;   //ROI数量

    //明亮区域的预处理
    Mat p_brightImage();
    //颜色区域的预处理 Red-1 Blue-2 Yellow-3
    Mat p_colorImage(const int color);
    //找到灯带
    Mat FindLight(Mat& brightImage, Mat& maskColor);
    //匹配成对的灯带
    vector<Mat> MatchLight(Mat& maskLight);
    //ROI区域预处理
    Mat p_ROI(Mat& ROI_o);
    //模板匹配识别数字
    int matchNum_Template(Mat& ROI);
    //模板匹配识别数字
    int matchNum_Hu(Mat& ROI);


private:







};

#endif