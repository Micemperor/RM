#include <iostream>
#include <cmath>
#include <string>
#include <vector>
#include <opencv2/opencv.hpp>
#include "Identify_num.h"
using namespace std;
using namespace cv;

Identify_num::Identify_num(Mat& img) : image(img) { }

Identify_num::~Identify_num() { }

Mat Identify_num::p_brightImage()
{   //明亮区域的预处理
    //转换为灰度图
    Mat grayImage;
    cvtColor(image, grayImage, COLOR_BGR2GRAY);
    //高斯滤波
    GaussianBlur(grayImage, grayImage, Size(15, 15), 0);
    //处理图像中的明亮区域，像素值>180
    Mat brightImage;
    threshold(grayImage, brightImage, 200, 255, THRESH_BINARY);
    //膨胀运算
    Mat element_dilate = getStructuringElement(MORPH_RECT, Size(3, 3));
    morphologyEx(brightImage, brightImage, MORPH_DILATE, element_dilate);
    return brightImage;
}

Mat Identify_num::p_colorImage(const int color)
{   //颜色区域的预处理 Red-1 Blue-2 Yellow-3
    //转换为HSV色彩空间
    Mat hsvImage;
    cvtColor(image, hsvImage, COLOR_BGR2HSV);
    int morph_size = 2;
    Mat element_close = getStructuringElement(MORPH_RECT,
        Size(2 * morph_size + 1, 2 * morph_size + 1),
        Point(morph_size, morph_size));

    if(color == 1)
    {
        //设定红色的HSV范围
        Scalar lowerRed1(0, 43, 46);
        Scalar upperRed1(10, 255, 255);
        Scalar lowerRed2(150, 43, 46);
        Scalar upperRed2(180, 255, 255);
        //创建掩膜
        Mat maskRed1, maskRed2, maskRed;   //红色区域
        inRange(hsvImage, lowerRed1, upperRed1, maskRed1);
        inRange(hsvImage, lowerRed2, upperRed2, maskRed2);
        bitwise_or(maskRed1, maskRed2, maskRed);   //合并红色掩膜
        morphologyEx(maskRed, maskRed, MORPH_CLOSE, element_close);   //闭操作
        return maskRed;
    }
    if(color == 2)
    {
        //设定蓝色的HSV范围
        Scalar lowerBlue(100, 43, 46);
        Scalar upperBlue(124, 255, 255);
        Mat maskBlue;   //蓝色区域
        inRange(hsvImage, lowerBlue, upperBlue, maskBlue);
        morphologyEx(maskBlue, maskBlue, MORPH_CLOSE, element_close);   //闭操作
        return maskBlue;
    }
    if(color == 3)
    {
        //设定黄色的HSV范围
        Scalar lowerYellow(11, 43, 46);
        Scalar upperYellow(34, 255, 255);
        Mat maskYellow;   //黄色区域
        inRange(hsvImage, lowerYellow, upperYellow, maskYellow);
        morphologyEx(maskYellow, maskYellow, MORPH_CLOSE, element_close);   //闭操作
        return maskYellow;
    }
}

Mat Identify_num::FindLight(Mat& brightImage, Mat& maskColor)
{   //找到灯带
    //找到明亮区域的轮廓
    vector<vector<Point>> contoursBright;
    findContours(brightImage, contoursBright, RETR_EXTERNAL, CHAIN_APPROX_SIMPLE);

    //创建一个与原图同样大小的掩膜来存储结果
    Mat maskLight = Mat::zeros(image.size(), CV_8UC1);

    //找到颜色区域的轮廓
    vector<vector<Point>> contoursColor;
    findContours(maskColor, contoursColor, RETR_CCOMP, CHAIN_APPROX_SIMPLE);

    //将所有颜色轮廓画在ColorMask上
    Mat ColorMask = Mat::zeros(image.size(), CV_8UC1);
    for (size_t i = 0; i < contoursColor.size(); i++)
    {
        if(contourArea(contoursColor[i]) >= 10)
            drawContours(ColorMask , vector<vector<Point>>(1, contoursColor[i]), -1, Scalar(255), FILLED);
    }

    //遍历颜色区域的轮廓，检查每个轮廓内部是否包含明亮区域
    for (size_t i = 0; i < contoursBright.size(); i++)
    {
        if(contourArea(contoursBright[i]) < 30)
            continue;

        Mat maskContour = Mat::zeros(image.size(), CV_8UC1);
        drawContours(maskContour, vector<vector<Point>>(1, contoursBright[i]), -1, Scalar(255), FILLED);

        //按位与操作，找到轮廓内部的明亮区域
        Mat brightContour;
            bitwise_and(ColorMask, maskContour, brightContour);

        //如果颜色轮廓内部有明亮区域，则为颜色灯光
        if (countNonZero(brightContour) > 0)       
            bitwise_or(maskLight, maskContour, maskLight);                     
    }
    return maskLight;
}

vector<Mat> Identify_num::MatchLight(Mat& maskLight)
{   //匹配成对的灯带
    vector<vector<Point>> matchLight;
    findContours(maskLight, matchLight, RETR_CCOMP, CHAIN_APPROX_SIMPLE);
    vector<Mat> ROI;
    //二重循环多条件匹配灯带
    for (size_t i = 0; i < matchLight.size(); i++)
    {
        for (size_t j = i + 1; j < matchLight.size(); j++)
        {          
            RotatedRect Light1 = minAreaRect(matchLight[i]);
            RotatedRect Light2 = minAreaRect(matchLight[j]);
            //灯带简单判断
            if((max(Light1.size.height,Light1.size.width) / min(Light1.size.height,Light1.size.width)) < 2 || (max(Light2.size.height,Light2.size.width) / min(Light2.size.height,Light2.size.width)) < 2)
                continue;
            float angle_diff = abs(Light1.angle - Light2.angle);   //角度之差
            float area1 = Light1.size.height * Light1.size.width;
            float area2 = Light2.size.height * Light2.size.width;
            float area_diff = abs(area1 - area2) / max(area1,area1);   //面积之差
            float height_diff = abs(Light1.size.height - Light2.size.height) / max(Light1.size.height, Light2.size.height);   //长度差比率
            float width_diff = abs(Light1.size.width - Light2.size.width) / max(Light1.size.width, Light2.size.width);   //宽度差比率
            if (angle_diff > 10 || area_diff > 1 || height_diff > 0.4 || width_diff > 0.4)
                continue;

            //利用装甲板判断
            RotatedRect ROIrect;    //装甲板
            ROIrect.center.x = (Light1.center.x + Light2.center.x) / 2;   //x坐标
            ROIrect.center.y = (Light1.center.y + Light2.center.y) / 2;   //y坐标
            ROIrect.angle = (Light1.angle + Light2.angle) / 2;   //角度
            float y_diff, x_diff;
            ROIrect.size.width = Light1.size.width + Light2.size.width; //高度
            // 宽度
            ROIrect.size.height = sqrt((Light1.center.x - Light2.center.x) * (Light1.center.x - Light2.center.x) + (Light1.center.y - Light2.center.y) * (Light1.center.y - Light2.center.y)) - Light1.size.height/2 - Light2.size.height/2;
            float ratio = ROIrect.size.width / ROIrect.size.height;   //匹配到的装甲板的长宽比
            x_diff = abs(Light1.center.x - Light2.center.x) / ROIrect.size.width; //x差比率
            y_diff = abs(Light1.center.y - Light2.center.y) / ROIrect.size.height; //y差比率
            if (ratio < 0.2 || ratio > 5.0 || x_diff < 0.5 || y_diff > 2.0)
                continue;
 
            //找到ROIrect
            Rect ROIBox = ROIrect.boundingRect();
            Mat temp;
            image(ROIBox).copyTo(temp);
            ROI.push_back(temp);
            n++;
            //绘制矩形               
            Point2f rect_points1[4];
            Point2f rect_points2[4];
            Point2f rect_pointsROIrect[4];
            Light1.points(rect_points1);
            Light2.points(rect_points2);
            ROIrect.points(rect_pointsROIrect);

            for (int j = 0; j < 4; j++)
            {
                line(image, rect_points1[j], rect_points1[(j + 1) % 4], Scalar(0,0,255), 2);
                line(image, rect_points2[j], rect_points2[(j + 1) % 4], Scalar(0,0,255), 2);
                line(image, rect_pointsROIrect[j], rect_pointsROIrect[(j + 1) % 4], Scalar(0,0,255), 2);
            }
            putText(image, format("R%d", n), Point(Light1.center.x, Light1.center.y), FONT_HERSHEY_SIMPLEX, 0.5, Scalar(0,0,255), 1);
            putText(image, format("R%d", n), Point(Light2.center.x, Light2.center.y), FONT_HERSHEY_SIMPLEX, 0.5, Scalar(0,0,255), 1);                       
            
        }
    }
    return ROI;
}


Mat Identify_num::p_ROI(Mat& ROI_o)
{   //ROI区域预处理
    //转换为灰度图
    Mat grayROI;
    cvtColor(ROI_o, grayROI, COLOR_BGR2GRAY);
    //高斯滤波
    GaussianBlur(grayROI, grayROI, Size(15, 15), 0);
    //像素值>150
    threshold(grayROI, grayROI, 123, 255, THRESH_BINARY);
    /*
    vector<vector<Point>> contourROI;
    findContours(grayROI, contourROI, RETR_EXTERNAL, CHAIN_APPROX_SIMPLE);
    int area = 0;
    int j = 0;
    for (size_t i = 0; i < contourROI.size(); i++)
    {
        if(contourArea(contourROI[i]) > area)
        {
            area = contourArea(contourROI[i]);
            j = i;
        }
    }
    RotatedRect ROIrect = minAreaRect(contourROI[j]);
    Rect ROIBox = ROIrect.boundingRect();
    Mat ROI = grayROI(ROIBox);
    grayROI(ROIBox).copyTo(ROI);
    */
    if(grayROI.rows > 190 && grayROI.cols > 240)   
        resize(grayROI, grayROI, Size(190, 240), grayROI.rows / 190, grayROI.cols / 240);  
    return grayROI;
}


int Identify_num::matchNum_Template(Mat& ROI)
{   
    //模板匹配识别数字   
    double bestVal = 0;

    Mat numImage_o = imread(format("/home/micemperor/桌面/Identify_num/num/num.png"), IMREAD_GRAYSCALE);
    Mat numImage = Mat::zeros(numImage_o.size(), numImage_o.type());
    bitwise_not(numImage_o, numImage);

    Mat result;
    matchTemplate(numImage, ROI, result, TM_CCOEFF_NORMED);
    double minVal, maxVal;
    Point minLoc, maxLoc;
    minMaxLoc(result, &minVal, &maxVal, &minLoc, &maxLoc);
    maxLoc.x += 50;
    if(maxVal < 0.2)
        return -1;     
    if(maxLoc.x >= 0 && maxLoc.x <= 200)
        return 0;
    if(maxLoc.x >= 201 && maxLoc.x <= 400)
        return 1;
    if(maxLoc.x >= 401 && maxLoc.x <= 600)
        return 2;
    if(maxLoc.x >= 601 && maxLoc.x <= 800)
        return 3;
    if(maxLoc.x >= 801 && maxLoc.x <= 1000)
        return 4;
    if(maxLoc.x >= 1001 && maxLoc.x <= 1200)
        return 5;
    if(maxLoc.x >= 1201 && maxLoc.x <= 1400)
        return 6;
    if(maxLoc.x >= 1401 && maxLoc.x <= 1600)
        return 7;
    if(maxLoc.x >= 1601 && maxLoc.x <= 1800)
        return 8;
    if(maxLoc.x >= 1801 && maxLoc.x <= 2000)
        return 9;
}

int Identify_num::matchNum_Hu(Mat& ROI)
{   //基于Hu矩的轮廓匹配
    int num = -1;
    //轮廓提取
    vector<vector<Point>> contourROI;
    findContours(ROI, contourROI, RETR_LIST, 2);
    //Hu矩计算
    Moments mm2 = moments(contourROI);
    Mat hu2;
    HuMoments(mm2, hu2);

    for(int i = 0; i<= 9; i++)
    {
        Mat numImage_o = imread(format("/home/micemperor/桌面/Identify_num/num/num.png"),IMREAD_GRAYSCALE);
        Mat numImage = Mat::zeros(numImage_o.size(), numImage_o.type());
        bitwise_not(numImage_o, numImage);
        
        vector<vector<Point>> contourNum;
        findContours(numImage, contourNum, RETR_LIST, 2);

        Moments mm = moments(contourNum);
        Mat hum;
        HuMoments(mm,hum);
        //Hu矩匹配
        double dist;
        dist = matchShapes(hum,hu2,CONTOURS_MATCH_I1,0);
        if(dist < 1)
        {
            //
        }
        
    }


}